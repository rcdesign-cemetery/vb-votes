-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 10 2010 г., 14:45
-- Версия сервера: 5.0.67
-- Версия PHP: 5.2.6-2ubuntu4.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `vbdebug`
--

-- --------------------------------------------------------

--
-- Структура таблицы `post_groan`
--

CREATE TABLE IF NOT EXISTS `post_groan` (
  `id` int(10) NOT NULL auto_increment,
  `userid` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `date` int(10) NOT NULL,
  `postid` int(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `postid` (`postid`),
  KEY `date` (`date`),
  KEY `user_date` (`userid`,`date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3651 ;

--
-- Дамп данных таблицы `post_groan`
--

INSERT INTO `post_groan` (`id`, `userid`, `username`, `date`, `postid`) VALUES
(3650, 54017, 'varnak', 1267803702, 1483345),
(3649, 54017, 'varnak', 1267803612, 1483346);
